/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : This is the code for main MCU, It handles the UART, RFID detection for
 * 					 warehouse A, the LEDs, Buzzer and inter MCU communication.
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "RC522.h"         // RFID reader library
#include "string.h"        // For string manipulation functions like strlen, memcmp
#include "stdio.h"         // For standard input/output functions like sprintf
#include "stdbool.h"       // For using boolean data type (true, false)

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

typedef enum {
	ITEM_STATE_NONE,  // Item is not currently in any warehouse
	ITEM_STATE_IN_A,   // Item is stored in warehouse A
	ITEM_STATE_IN_B    // Item is stored in warehouse B
} ItemState_t;

/* Structure to hold information about each RFID-tagged item*/
typedef struct {
	uint8_t uid[5];          // Unique identifier (UID) of the RFID tag (5 bytes)
	const char* name;        // A descriptive name for the item (e.g., "Item 1")
	ItemState_t state;       // The current location of the item (using the ItemState_t enum)
	uint8_t uart1_command_id; // A command ID associated with this item, used for UART1 communication (Warehouse B)
	const char* msg_stored_a; // Message to send when item is stored in warehouse A
	const char* msg_exited_a; // Message to send when item exits warehouse A
	const char* msg_stored_b; // Message to send when item is stored in warehouse B
	const char* msg_exited_b; // Message to send when item exits warehouse B
} RFID_Item_t;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define NUM_ITEMS 4  // Define the number of RFID-tagged items being tracked
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;
TIM_HandleTypeDef htim2;
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint8_t rfid_status;         // Stores the return status code from MFRC522 RFID reader functions
uint8_t rfid_tag_type[2];    // Buffer to store the tag type returned by MFRC522_Request()
uint8_t rfid_detected_uid[5]; // Buffer to store the detected RFID tag's unique ID (UID)

uint8_t uart1_rx_byte_buffer[1]; // Buffer to hold the received byte from UART1 (for commands)
volatile uint8_t uart1_command;  // Variable to store the received UART1 command
volatile bool new_uart1_command_flag = false; // Flag to indicate a new UART1 command has been received


// --- Item Definitions (Ensure UIDs are correct for your tags!) ---
RFID_Item_t items[NUM_ITEMS] = {
		// Each item is initialized with its UID, name, initial state, UART1 command ID, and messages
		{ {0x4D, 0xE4, 0x22, 0x03, 0x88}, "Item 1", ITEM_STATE_NONE, 1,
				"Item 1 Stored in warehouse A\r\n", "Item 1 exited warehouse A\r\n",
				"Item 1 Stored in warehouse B\r\n", "Item 1 exited warehouse B\r\n" },
		{ {0xC3, 0x3D, 0x82, 0x14, 0x68}, "Item 2", ITEM_STATE_NONE, 2,
				"Item 2 Stored in warehouse A\r\n", "Item 2 exited warehouse A\r\n",
				"Item 2 Stored in warehouse B\r\n", "Item 2 exited warehouse B\r\n" },
		{ {0x7B, 0x82, 0x31, 0x03, 0xCB}, "Item 3", ITEM_STATE_NONE, 3,
				"Item 3 Stored in warehouse A\r\n", "Item 3 exited warehouse A\r\n",
				"Item 3 Stored in warehouse B\r\n", "Item 3 exited warehouse B\r\n" },
		{ {0xD3, 0x84, 0x2D, 0x2D, 0x57}, "Item 4", ITEM_STATE_NONE, 4,
				"Item 4 Stored in warehouse A\r\n", "Item 4 exited warehouse A\r\n",
				"Item 4 Stored in warehouse B\r\n", "Item 4 exited warehouse B\r\n" }
};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
void Blink_PA5(uint32_t duration_ms); // Function to blink GPIOA pin 5 for a given duration
void Blink_RED_LED_PA4(uint32_t duration_ms); // Function to blink GPIOA pin 4 for a given duration
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{

	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART2_UART_Init();
	MX_SPI1_Init();
	MX_USART1_UART_Init();
	MX_TIM2_Init();
	/* USER CODE BEGIN 2 */
	MFRC522_Init(); // Initialize RFID Reader

	// Start UART1 reception for commands
	HAL_UART_Receive_IT(&huart1, uart1_rx_byte_buffer, 1);

	HAL_UART_Transmit(&huart2, (uint8_t*)"System Ready. Stricter Inventory Control.\r\n",
			strlen("System Ready. Stricter Inventory Control.\r\n"), HAL_MAX_DELAY);
	HAL_TIM_Base_Start(&htim2);


	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
		char message_buffer[100]; // Buffer for dynamic messages (like errors)

		// --- Warehouse A: RFID Detection ---
		rfid_status = MFRC522_Request(PICC_REQIDL, rfid_tag_type); // Request a tag in idle mode
		if (rfid_status == MI_OK) { // If a tag is found
			rfid_status = MFRC522_Anticoll(rfid_detected_uid); // Anti-collision, read tag UID
			if (rfid_status == MI_OK) { // If UID is read successfully

				for (int i = 0; i < NUM_ITEMS; i++) { // Iterate through the list of items
					if (memcmp(rfid_detected_uid, items[i].uid, 5) == 0) { // Compare detected UID with item UID
						// Item found, process based on its current state and this detection (Warehouse A)
						if (items[i].state == ITEM_STATE_NONE) { // Item is not in any warehouse
							// Item is not in any warehouse, so store it in A
							HAL_UART_Transmit(&huart2, (uint8_t*)items[i].msg_stored_a, strlen(items[i].msg_stored_a), HAL_MAX_DELAY); // Send message
							items[i].state = ITEM_STATE_IN_A; // Update item state
							Blink_PA5(2000); // Blink PA5 for 2 seconds
						} else if (items[i].state == ITEM_STATE_IN_A) { // Item is already in A
							// Item is already in A, so this scan means it's exiting A
							HAL_UART_Transmit(&huart2, (uint8_t*)items[i].msg_exited_a, strlen(items[i].msg_exited_a), HAL_MAX_DELAY); // Send message
							items[i].state = ITEM_STATE_NONE; // Update item state
							Blink_RED_LED_PA4(1000);
						} else if (items[i].state == ITEM_STATE_IN_B) { // Item is in Warehouse B
							// Item is in Warehouse B, but scanned at Warehouse A. This is an error.
							sprintf(message_buffer, "ERROR (%s): Item in Warehouse B. Must exit B before entering A.\r\n", items[i].name); // Format error message
							HAL_UART_Transmit(&huart2, (uint8_t*)message_buffer, strlen(message_buffer), HAL_MAX_DELAY); // Send error message
							HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
							HAL_Delay(1000);
							HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
						}

						HAL_Delay(2000); // Debounce ,prevent rapid re-scan
						break; // Item processed
					}
				}
			}
		}

		// --- Warehouse B: UART1 Command Processing ---
		if (new_uart1_command_flag) { // If a new UART1 command has been received
			uint8_t current_command = uart1_command; // Store the current command
			new_uart1_command_flag = false; // Reset the flag

			for (int i = 0; i < NUM_ITEMS; i++) { // Iterate through the list of items
				if (items[i].uart1_command_id == current_command) { // Check if the command matches an item
					// Command matches an item, process based on its current state and this command (Warehouse B)
					if (items[i].state == ITEM_STATE_NONE) { // Item is not in any warehouse
						// Item is not in any warehouse, so store it in B
						HAL_UART_Transmit(&huart2, (uint8_t*)items[i].msg_stored_b, strlen(items[i].msg_stored_b), HAL_MAX_DELAY); // Send message
						items[i].state = ITEM_STATE_IN_B; // Update item state
						Blink_PA5(2000); // Blink PA5 for 2 seconds
					} else if (items[i].state == ITEM_STATE_IN_B) { // Item is already in B
						// Item is already in B, so this command means it's exiting B
						HAL_UART_Transmit(&huart2, (uint8_t*)items[i].msg_exited_b, strlen(items[i].msg_exited_b), HAL_MAX_DELAY); // Send message
						items[i].state = ITEM_STATE_NONE; // Update item state
						Blink_RED_LED_PA4(1000); //Blink RED LED
					} else if (items[i].state == ITEM_STATE_IN_A) { // Item is in Warehouse A
						// Item is in Warehouse A, but command received for Warehouse B. This is an error.
						sprintf(message_buffer, "ERROR (%s): Item in Warehouse A. Must exit A before entering B.\r\n", items[i].name); // Format error message
						HAL_UART_Transmit(&huart2, (uint8_t*)message_buffer, strlen(message_buffer), HAL_MAX_DELAY); // Send error message

						HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
						HAL_Delay(1000);

						HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);


					}
					HAL_Delay(2000); // Debounce/feedback delay
					break; // Command processed
				}
			}
		}
		HAL_Delay(50); // General main loop delay to yield CPU slightly
		/* USER CODE END 3 */
	}
}
/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	/** Configure the main internal regulator output voltage
	 */
	HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
	RCC_OscInitStruct.PLL.PLLN = 8;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
	RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
			|RCC_CLOCKTYPE_PCLK1;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
	{
		Error_Handler();
	}
}

/**
 * @brief SPI1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_SPI1_Init(void)
{

	/* USER CODE BEGIN SPI1_Init 0 */

	/* USER CODE END SPI1_Init 0 */

	/* USER CODE BEGIN SPI1_Init 1 */

	/* USER CODE END SPI1_Init 1 */
	/* SPI1 parameter configuration*/
	hspi1.Instance = SPI1;
	hspi1.Init.Mode = SPI_MODE_MASTER;
	hspi1.Init.Direction = SPI_DIRECTION_2LINES;
	hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
	hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
	hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
	hspi1.Init.NSS = SPI_NSS_SOFT;
	hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
	hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
	hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
	hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspi1.Init.CRCPolynomial = 7;
	hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
	hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
	if (HAL_SPI_Init(&hspi1) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN SPI1_Init 2 */

	/* USER CODE END SPI1_Init 2 */

}

/**
 * @brief TIM2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM2_Init(void)
{

	/* USER CODE BEGIN TIM2_Init 0 */

	/* USER CODE END TIM2_Init 0 */

	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};
	TIM_OC_InitTypeDef sConfigOC = {0};

	/* USER CODE BEGIN TIM2_Init 1 */

	/* USER CODE END TIM2_Init 1 */
	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 63;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 999;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = 500;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
	if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM2_Init 2 */

	/* USER CODE END TIM2_Init 2 */
	HAL_TIM_MspPostInit(&htim2);

}

/**
 * @brief USART1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART1_UART_Init(void)
{

	/* USER CODE BEGIN USART1_Init 0 */

	/* USER CODE END USART1_Init 0 */

	/* USER CODE BEGIN USART1_Init 1 */

	/* USER CODE END USART1_Init 1 */
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
	huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart1) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN USART1_Init 2 */

	/* USER CODE END USART1_Init 2 */

}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART2_UART_Init(void)
{

	/* USER CODE BEGIN USART2_Init 0 */

	/* USER CODE END USART2_Init 0 */

	/* USER CODE BEGIN USART2_Init 1 */

	/* USER CODE END USART2_Init 1 */
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 115200;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
	huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN USART2_Init 2 */

	/* USER CODE END USART2_Init 2 */

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	/* USER CODE BEGIN MX_GPIO_Init_1 */

	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, RED_LED_Pin|GPIO_PIN_5|RESET_RFID_1_Pin|RESET_RFID_2_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, RED_1_Pin|Green_2_Pin|RED_2_Pin|SDA_RFID_2_Pin
			|SDA_RFID_1_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pins : RED_LED_Pin RESET_RFID_1_Pin RESET_RFID_2_Pin */
	GPIO_InitStruct.Pin = RED_LED_Pin|RESET_RFID_1_Pin|RESET_RFID_2_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pin : PA5 */
	GPIO_InitStruct.Pin = GPIO_PIN_5;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : RED_1_Pin Green_2_Pin RED_2_Pin SDA_RFID_2_Pin
                           SDA_RFID_1_Pin */
	GPIO_InitStruct.Pin = RED_1_Pin|Green_2_Pin|RED_2_Pin|SDA_RFID_2_Pin
			|SDA_RFID_1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* USER CODE BEGIN MX_GPIO_Init_2 */

	/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1)
	{
		uart1_command = uart1_rx_byte_buffer[0];
		new_uart1_command_flag = true;

		// Re-arm the interrupt for the next byte
		HAL_UART_Receive_IT(&huart1, uart1_rx_byte_buffer, 1);
	}
}

void Blink_PA5(uint32_t duration_ms) {
	uint32_t start_time = HAL_GetTick();
	while ((HAL_GetTick() - start_time) < duration_ms) {
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
		HAL_Delay(100); // Adjust delay for desired blink speed
	}
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET); // Ensure it's off at the end
}

void Blink_RED_LED_PA4(uint32_t duration_ms) {
	uint32_t start_time = HAL_GetTick();
	while ((HAL_GetTick() - start_time) < duration_ms) {
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_4);
		HAL_Delay(100); // Adjust delay for desired blink speed
	}
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET); // Ensure it's off at the end
}
/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	__disable_irq();
	// Transmit error over UART if possible, or blink LED rapidly
	const char *errMsg = "FATAL ERROR!\r\n";
	// Use a short timeout for UART transmit in error handler
	HAL_UART_Transmit(&huart2, (uint8_t*)errMsg, strlen(errMsg), 100);

	//
	//
	//  // Toggle LED five times - ensure LED_GREEN_GPIO_Port and LED_GREEN_Pin are defined if uncommented
	//  // Or use PA5 directly:
	//  for (int i = 0; i < 10; i++) { // Blink more rapidly for fatal error
	//      HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
	//      HAL_Delay(100);
	//  }


	while (1)
	{
		// HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5); // Continuous rapid blink
		// for(volatile uint32_t i = 0; i < 0x1FFFF; i++); // Crude delay
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	char msg[100];
	sprintf(msg, "Wrong parameters value: file %s on line %lu\r\n", (char *)file, line);
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 1000); // Send assert message
	Error_Handler(); // Go to error handler
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
